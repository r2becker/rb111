# Script to echo hello to the standard out ($1)
echo hello
echo $0
echo $1
echo $?
